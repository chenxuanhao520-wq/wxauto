"""
结构验证器（简化版）
从etl模块导入
"""
from ..etl.structure_validator import StructureValidator, DocumentTemplate

__all__ = ['StructureValidator', 'DocumentTemplate']
