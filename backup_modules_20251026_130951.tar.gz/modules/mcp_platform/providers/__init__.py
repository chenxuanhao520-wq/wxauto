"""
MCP 服务提供商
封装第三方服务为 MCP 标准接口
"""

from .zhibang_erp_provider import ZhibangERPProvider

__all__ = ["ZhibangERPProvider"]

